"""CPU float64 equal-probability ensemble of two original parents.

Components, in order, are curve_C_lr003_s0 and curve_C_lr003_s2.
Each weight is 1/2. Each parent is weights-only. Saved tensors stay
float32 on disk and are cast with model.double(). Softmax is not cast
to float32. The tensor float method is not reassigned. Both component
hashes, configs, keys, shapes, kernel extents, saved dtypes, and
finiteness are checked before history or queries are read. A third
checkpoint cannot be selected. This file does not train.
"""
from __future__ import annotations

import argparse
import csv
import hashlib
import json
import os
import resource
import sys
import time
from pathlib import Path

os.environ["OMP_NUM_THREADS"] = "2"
os.environ["MKL_NUM_THREADS"] = "2"
os.environ["OPENBLAS_NUM_THREADS"] = "2"
os.environ["CUDA_VISIBLE_DEVICES"] = ""
os.environ["HIP_VISIBLE_DEVICES"] = ""

HERE = Path(__file__).resolve().parent
COMPONENT_PATHS = {
    "s0": {
        "checkpoint": "components/s0/checkpoint.pt",
        "config": "components/s0/config.json",
    },
    "s2": {
        "checkpoint": "components/s2/checkpoint.pt",
        "config": "components/s2/config.json",
    },
}
MODEL_PY_SHA256 = "7e63ccf7ad5b1177071d931aca13713390a5bdcc667f69652f6f97aa7e6c527a"
DATA_PY_SHA256 = "af23684b5348c53dafc0e3870706da7ed3dc64c852537371ac7c0ee97d916133"
WEIGHTS_SHA256 = "30dad61dbcb82a33fb4a72c5296ae9ad700c2c0ff92fff629403703a40139e9f"
PROBABILITY_COLUMNS = ("p_0", "p_1", "p_2", "p_5", "p_20")
KERNEL = 3
H = 128
LAYERS = 4
FORWARD_BATCH = 4
COMPONENTS = (
    {
        "id": "s0",
        "role": "curve_C_lr003_s0",
        "checkpoint_sha256": "d5d714649a93e1e552ccf5419cb01adee311c082af1063f80d8b42f6d8dfe3cb",
        "config_sha256": "7ddfe3a4dd1439945c6145d1d5cc2a868653ba30f25523890bf95f5e23aa10ac",
        "expected_config": {
            "lr": 0.003,
            "wd": 0.00895,
            "bs": 512,
            "epochs": 30,
            "drop": 0.3,
            "h": 128,
            "layers": 4,
            "W": 64,
            "seed": 0,
            "pct_start": 0.3,
            "eval_every": 2,
            "out": "experiments/cnn03_convergence/runs/curve_C_lr003_s0",
        },
    },
    {
        "id": "s2",
        "role": "curve_C_lr003_s2",
        "checkpoint_sha256": "bcef4104371484eedabce1ab1aca5fc340dcf0e4e2c4e6b2c946f0a1789e1f71",
        "config_sha256": "a715bfe05eb00494065c7dfcc3ad6d71a3b2bc4ee6788006cf07ce86f3e43695",
        "expected_config": {
            "lr": 0.003,
            "wd": 0.00895,
            "bs": 512,
            "epochs": 30,
            "drop": 0.3,
            "h": 128,
            "layers": 4,
            "W": 64,
            "seed": 2,
            "pct_start": 0.3,
            "eval_every": 2,
            "out": "experiments/cnn03_convergence/runs/curve_C_lr003_s2",
        },
    },
)


def fail(message: str) -> None:
    print(f"REFUSED: {message}", file=sys.stderr)
    raise SystemExit(2)


def sha256_file(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1 << 20), b""):
            digest.update(chunk)
    return digest.hexdigest()


def expected_shapes() -> dict[str, tuple[int, ...]]:
    shapes = {
        "pay.weight": (6, H),
        "mask.weight": (H, 1),
        "mask.bias": (H,),
        "typ.weight": (3, H),
        "slot.weight": (8, H),
        "tick.weight": (H, 2),
        "tick.bias": (H,),
        "head.0.weight": (H, 2 * H),
        "head.0.bias": (H,),
        "head.2.weight": (5, H),
        "head.2.bias": (5,),
    }
    for i in range(LAYERS):
        prefix = f"blocks.{i}"
        shapes[f"{prefix}.conv.weight"] = (H, H, KERNEL)
        shapes[f"{prefix}.conv.bias"] = (H,)
        shapes[f"{prefix}.mix.weight"] = (H, 2 * H)
        shapes[f"{prefix}.mix.bias"] = (H,)
        shapes[f"{prefix}.n1.weight"] = (H,)
        shapes[f"{prefix}.n1.bias"] = (H,)
        shapes[f"{prefix}.n2.weight"] = (H,)
        shapes[f"{prefix}.n2.bias"] = (H,)
    return shapes


def unclean_config(cfg, expected: dict, cid: str) -> str | None:
    if not isinstance(cfg, dict):
        return f"{cid} checkpoint config is not an object"
    if cfg.get("no_signal") is False:
        return f"{cid} unclean config: signal mode refused"
    if set(cfg) != set(expected):
        return f"{cid} unclean config: keys do not match the {cid} parent"
    for key, value in expected.items():
        if cfg[key] != value:
            return f"{cid} unclean config: {key} does not match the {cid} parent"
    return None


def configs_equal(checkpoint_cfg: dict, packaged_cfg: dict) -> bool:
    if set(checkpoint_cfg) != set(packaged_cfg):
        return False
    for key, value in packaged_cfg.items():
        if checkpoint_cfg[key] != value:
            return False
    return True


def signal_keys(state) -> list[str]:
    return [str(key) for key in state if key == "sig.weight" or str(key).startswith("sig.")]


def state_reason(state, cid: str) -> str | None:
    if not isinstance(state, dict):
        return f"{cid} checkpoint state is not an object"
    leaked = signal_keys(state)
    if leaked:
        return f"{cid} signal mode refused: " + ", ".join(leaked)
    want = expected_shapes()
    if len(want) != 43:
        return "internal shape table is not 43 tensors"
    if set(state) != set(want):
        missing = sorted(set(want) - set(state))
        extra = sorted(set(state) - set(want))
        return f"{cid} architecture keys mismatch missing={missing} extra={extra}"
    import torch
    for key, shape in want.items():
        tensor = state[key]
        got = tuple(tensor.shape)
        if got != shape:
            return f"{cid} {key} shape {got} != {shape}"
        if tensor.dtype != torch.float32:
            return f"{cid} {key} saved dtype {tensor.dtype} is not float32"
        if not bool(torch.isfinite(tensor).all()):
            return f"{cid} {key} is not finite"
    return None


def canonical_renorm(values) -> list[float]:
    vals = [float(v) for v in values]
    if any(v != v or v in (float("inf"), float("-inf")) for v in vals):
        fail("non-finite probability")
    total = sum(vals)
    if not total > 0.0:
        fail("probability mass is not positive")
    return [v / total for v in vals]


def renorm_map(preds: dict[str, list[float]]) -> dict[str, list[float]]:
    return {key: canonical_renorm(row) for key, row in preds.items()}


def equal_probability_mean(maps: list[dict[str, list[float]]]) -> dict[str, list[float]]:
    if len(maps) != 2:
        fail(f"ensemble component count {len(maps)} is not 2")
    keys = set(maps[0])
    if set(maps[1]) != keys:
        fail("ensemble query ids differ")
    out = {}
    for key in keys:
        mixed = [(maps[0][key][i] + maps[1][key][i]) / 2.0 for i in range(5)]
        out[key] = canonical_renorm(mixed)
    return out


def assert_source_files() -> None:
    model_path = HERE / "model.py"
    data_path = HERE / "data.py"
    if not model_path.is_file() or model_path.is_symlink():
        fail("missing model.py")
    if not data_path.is_file() or data_path.is_symlink():
        fail("missing data.py")
    model_hash = sha256_file(model_path)
    data_hash = sha256_file(data_path)
    if model_hash != MODEL_PY_SHA256:
        fail(f"model.py hash mismatch {model_hash}")
    if data_hash != DATA_PY_SHA256:
        fail(f"data.py hash mismatch {data_hash}")


def assert_component_tree() -> None:
    root = HERE / "components"
    if not root.is_dir() or root.is_symlink():
        fail("missing components directory")
    names = sorted(path.name for path in root.iterdir())
    if names != ["s0", "s2"]:
        fail(f"unexpected component directory {names}")
    for cid in ("s0", "s2"):
        folder = root / cid
        if not folder.is_dir() or folder.is_symlink():
            fail(f"{cid} component path is not a real directory")
        files = sorted(path.name for path in folder.iterdir())
        if files != ["checkpoint.pt", "config.json"]:
            fail(f"unexpected files in {cid}: {files}")
        for name in files:
            path = folder / name
            if path.is_symlink() or not path.is_file():
                fail(f"{cid} {name} is not a real file")


def assert_weights_manifest() -> None:
    path = HERE / "provenance" / "weights.json"
    if not path.is_file() or path.is_symlink():
        fail("missing provenance/weights.json")
    digest = sha256_file(path)
    if digest != WEIGHTS_SHA256:
        fail(f"weights manifest hash mismatch {digest}")
    payload = json.loads(path.read_text(encoding="utf-8"))
    if payload.get("order") != ["s0", "s2"]:
        fail("weights manifest order is not s0 then s2")
    if payload.get("weights") != [0.5, 0.5]:
        fail("weights manifest weights are not 0.5 and 0.5")
    if payload.get("name") != "ensemble_equal_s0_s2":
        fail("weights manifest name is not ensemble_equal_s0_s2")
    rows = payload.get("components")
    if not isinstance(rows, list) or len(rows) != 2:
        fail("weights manifest component list is not the two parents")
    for spec, row in zip(COMPONENTS, rows):
        if row.get("id") != spec["id"] or row.get("role") != spec["role"]:
            fail(f"{spec['id']} weights manifest identity mismatch")
        if row.get("checkpoint") != COMPONENT_PATHS[spec["id"]]["checkpoint"]:
            fail(f"{spec['id']} weights manifest path mismatch")
        if row.get("config") != COMPONENT_PATHS[spec["id"]]["config"]:
            fail(f"{spec['id']} weights manifest config path mismatch")
        if row.get("checkpoint_sha256") != spec["checkpoint_sha256"]:
            fail(f"{spec['id']} weights manifest checkpoint pin mismatch")
        if row.get("config_sha256") != spec["config_sha256"]:
            fail(f"{spec['id']} weights manifest config pin mismatch")
        if int(row.get("seed")) != spec["expected_config"]["seed"]:
            fail(f"{spec['id']} weights manifest seed mismatch")


def load_component(spec: dict):
    cid = spec["id"]
    config_path = HERE / COMPONENT_PATHS[cid]["config"]
    checkpoint_path = HERE / COMPONENT_PATHS[cid]["checkpoint"]
    config_hash = sha256_file(config_path)
    if config_hash != spec["config_sha256"]:
        fail(f"{cid} unclean config hash {config_hash}")
    packaged_cfg = json.loads(config_path.read_text(encoding="utf-8"))
    packaged_reason = unclean_config(packaged_cfg, spec["expected_config"], cid)
    if packaged_reason:
        fail(packaged_reason)
    checkpoint_hash = sha256_file(checkpoint_path)
    import torch
    torch.set_num_threads(2)
    try:
        blob = torch.load(checkpoint_path, map_location="cpu", weights_only=False)
    except TypeError:
        blob = torch.load(checkpoint_path, map_location="cpu")
    except Exception as exc:
        if checkpoint_hash != spec["checkpoint_sha256"]:
            fail(f"{cid} checkpoint hash mismatch {checkpoint_hash}")
        fail(f"{cid} checkpoint unreadable: {exc}")
    if not isinstance(blob, dict) or set(blob) != {"config", "state"}:
        fail(f"{cid} checkpoint is not weights-only")
    reason = state_reason(blob["state"], cid)
    if reason:
        fail(reason)
    cfg = blob.get("config")
    config_reason = unclean_config(cfg, spec["expected_config"], cid)
    if config_reason:
        fail(config_reason)
    if not configs_equal(cfg, packaged_cfg):
        fail(f"{cid} unclean config: checkpoint config does not match config.json")
    if checkpoint_hash != spec["checkpoint_sha256"]:
        fail(f"{cid} checkpoint hash mismatch {checkpoint_hash}")
    return blob, cfg


def build_net(blob: dict, cfg: dict, cid: str):
    import torch
    import model as model_mod
    from model import CNN

    if torch.is_autocast_enabled() or torch.is_autocast_enabled("cpu"):
        fail("autocast is enabled")
    model_mod.USE_SIGNAL = False
    net = CNN(cfg["h"], cfg["layers"], KERNEL, cfg["drop"], cfg["W"], use_signal=False)
    for index, block in enumerate(net.blocks):
        if tuple(block.conv.weight.shape) != (H, H, KERNEL):
            fail(f"{cid} blocks.{index}.conv.weight kernel contract failed")
    net.load_state_dict(blob["state"])
    net.double()
    net.eval()
    if net.use_signal or net.sig is not None:
        fail(f"{cid} signal mode refused")
    floating = [p for p in net.parameters() if p.is_floating_point()]
    if len(floating) != 43 or any(p.dtype != torch.float64 for p in floating):
        fail(f"{cid} floating parameters are not 43 float64 tensors")
    return net


def prepare():
    """Check both parents and build both networks before any split is read."""
    assert_source_files()
    assert_component_tree()
    assert_weights_manifest()
    prepared = []
    for spec in COMPONENTS:
        blob, cfg = load_component(spec)
        net = build_net(blob, cfg, spec["id"])
        prepared.append((spec, blob, cfg, net))
    import torch
    if torch.is_autocast_enabled() or torch.is_autocast_enabled("cpu"):
        fail("autocast is enabled")
    return prepared


def write_submission_csv(path: Path, predictions: dict[str, list[float]]) -> None:
    rows = []
    for query_id in sorted(predictions):
        values = canonical_renorm(predictions[query_id])
        rows.append([query_id, *[repr(v) for v in values]])
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", newline="", encoding="utf-8") as handle:
        writer = csv.writer(handle, lineterminator="\n")
        writer.writerow(("query_id", *PROBABILITY_COLUMNS))
        writer.writerows(rows)


def predict_split(data_dir: str, split: str):
    prepared = prepare()
    from data import load_public_split
    from model import build_query, predict, to_preds

    try:
        data = load_public_split(data_dir, split)
    except (OSError, ValueError, KeyError) as exc:
        fail(f"missing or unreadable {split} history/queries: {exc}")
    if not data.queries:
        fail(f"{split} queries are empty")
    features, episodes = build_query(data, prepared[0][2]["W"])
    if any(int(row.sum()) != 0 for row in features[3]):
        fail("signal features were not all zero")
    maps = []
    seconds = []
    for spec, _blob, cfg, net in prepared:
        started = time.perf_counter()
        probabilities = predict(net, features, "cpu", bs=FORWARD_BATCH)
        seconds.append(time.perf_counter() - started)
        if str(probabilities.dtype) != "float64":
            fail(f"{spec['id']} predict dtype {probabilities.dtype}")
        component_map = to_preds(probabilities, episodes, data)
        if len(component_map) != len(data.queries):
            fail(f"{spec['id']} query coverage mismatch")
        maps.append(renorm_map(component_map))
    mixed = equal_probability_mean(maps)
    if len(mixed) != len(data.queries):
        fail("ensemble query coverage mismatch")
    stats = {
        "s0_infer_s": seconds[0],
        "s2_infer_s": seconds[1],
        "infer_s": seconds[0] + seconds[1],
        "queries": len(mixed),
        "max_rss_kb": resource.getrusage(resource.RUSAGE_SELF).ru_maxrss,
    }
    return mixed, stats


def main(argv: list[str] | None = None) -> None:
    started = time.perf_counter()
    parser = argparse.ArgumentParser(description="CPU float64 equal ensemble of original seeds 0 and 2")
    parser.add_argument("--data", required=True, help="Round public directory")
    parser.add_argument("--out", required=True, help="Destination submission CSV path")
    parser.add_argument("--split", default="test", choices=("test", "val", "validation"))
    args = parser.parse_args(argv)
    split = "validation" if args.split == "val" else args.split
    predictions, stats = predict_split(args.data, split)
    write_submission_csv(Path(args.out), predictions)
    print(
        f"wrote {args.out} split={split} queries={stats['queries']} "
        f"components=s0,s2 weights=0.5,0.5 "
        f"s0_infer_s={stats['s0_infer_s']:.6f} s2_infer_s={stats['s2_infer_s']:.6f} "
        f"infer_s={stats['infer_s']:.6f} total_s={time.perf_counter() - started:.6f} "
        f"max_rss_kb={stats['max_rss_kb']} device=cpu dtype=fp64 threads=2 forward_batch=4",
        file=sys.stderr,
    )


if __name__ == "__main__":
    main()
