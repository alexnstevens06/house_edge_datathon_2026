# Equal ensemble of original curve_C_lr003 seeds 0 and 2

- Team ID: not supplied
- Round: main
- Forecast file: generated separately. This ZIP has no cached forecast.
- Code version: original parent checkpoints, equal probability weights 0.5 and 0.5
- Seed 0 checkpoint SHA-256: `d5d714649a93e1e552ccf5419cb01adee311c082af1063f80d8b42f6d8dfe3cb`
- Seed 2 checkpoint SHA-256: `bcef4104371484eedabce1ab1aca5fc340dcf0e4e2c4e6b2c946f0a1789e1f71`
- Environment: `python` in `reproduce.json`
- Status: separately staged candidate for a packaging proof. Not a release. Not a production replacement. Not organizer acceptance. Not an automatic canonical replacement. Technical CPU offline checks are not organizer acceptance.

## What is pinned

Both weight files are the original parents `experiments/cnn03_convergence/runs/curve_C_lr003_s0/checkpoint.pt` and `experiments/cnn03_convergence/runs/curve_C_lr003_s2/checkpoint.pt`. Each file is weights-only (`config` and `state`). Order is seed 0, then seed 2. Each already-normalized probability row is averaged with weight 0.5, then normalized again by a float sum. The parents are not low-rate continuations, not a blend, and not the shared control.

Each saved config is lr 0.003, wd 0.00895, bs 512, epochs 30, drop 0.3, h 128, layers 4, W 64, pct_start 0.3, eval_every 2, and that parent's original `out` path. Seed 0 and seed 2 differ. Neither config grew a `kernel`, `model`, `phase`, or `no_signal` field. Kernel 3 is the measured `blocks.*.conv.weight` shape `(128, 128, 3)` on all four layers of both parents. All 43 tensors in each parent are finite float32 on disk and float64 after `model.double()`.

Selection context, not a hidden-test claim: comparative TUNE-only R of this ensemble is 0.28468175920919014 on 384 tune rows. Current best single-model TUNE R is 0.30980333573689856. The recorded improvement is 0.02512157652770841. The pair was chosen after many predeclared TUNE comparisons. There is no significance claim and no claim that a held-out split was never seen. Earlier packaging already printed public full-validation diagnostics. This package does not compute confirm, full, or test R. The GPU 5e-5 arm did not finish: native RSS stopped it, so this package does not claim that all four low-rate jobs completed, and it does not claim a win over an unrun checkpoint.

## Setup

- Python target: CPython 3.13 with the CPU stack named in `requirements.txt`. The lock text is the canonical 11-package lock copied byte-for-byte. This package does not download it.
- Dependencies: `numpy==2.5.4` and `torch==2.11.0+cpu`. Organizer kit text says the root pins are preinstalled and the rerun is then offline. The live guide also describes a standard-library image, an offered environment, and offline wheels. That conflict is unresolved here. No wheel is bundled, so the archive stays under 100 MB.
- Direct CPU wheel, not downloaded by this package: `torch-2.11.0+cpu-cp313-cp313-manylinux_2_28_x86_64.whl` SHA-256 `45025d7752dbc6b4c784c03afaee9c5f19730ce084b2e43fc9a2fe1677d9ff86`.
- Hardware: 2 CPU cores. The process asks for 2 threads. No GPU. Actual resident memory is measured by the local proof and is not copied from a one-model package.
- Data: `/data` is the public round directory. The default command reads only `/data/test/history.csv` and `/data/test/queries.csv`. Paths inside the ZIP are package-relative. The archive does not point at a repo checkout or a dataset path on the author machine.

`organizer_approval_claimed` is false. The command checks both config files, both checkpoints, `model.py`, `data.py`, and `provenance/weights.json` against pinned SHA-256 values. It checks 43 keys, shapes, kernel 3, finite float32 storage, and the ordered weights 0.5/0.5 before it reads a split. Softmax is not cast back to float32. Labels, conditions, targets, reference files, and the signal column are not used. The process does not train and does not write a checkpoint.

## Recreate the forecast

Run from this directory:

```sh
python predict.py --data /data --out /output/submission.csv
```

`reproduce.json` is that command with image `python`. `--split val` reads `validation/history.csv` and `validation/queries.csv` for a local structural check. The default split remains `test`.

- Required files: `components/s0/checkpoint.pt`, `components/s0/config.json`, `components/s2/checkpoint.pt`, `components/s2/config.json`, `provenance/weights.json`, `model.py`, `data.py`, `predict.py`
- Settings: both packaged config files, equal to the checkpoint configs, and `provenance/weights.json`
- What it does: loads both original parents and writes the equal probability mean
- Training command: none

If either config hash, either checkpoint hash, the weight manifest, the key set, a shape, the saved dtype, or finiteness does not match, the process exits 2 and writes no CSV.

## Local check

```sh
python check_submission.py path/to/submission.csv --data path/to/public
```

Local checks do not submit an entry. This ZIP was not uploaded.
